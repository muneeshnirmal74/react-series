import React from "react";
import Card from "./Card";

function Section2(props) {
  return (
    <div className="section2 flex-3 flex gap-5">
      {props.user.map((item, index) => {
        return <Card  user={item}/>;
      })}
    </div>
  );
}

export default Section2;