import React from "react";

function Card({user }) {
  return (
    <>
      <div className="card flex-1 relative  rounded-[10px] ">
        <img
          src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7"
          alt="Placeholder Image" className="rounded-[20px]"
        />
        <div className="card-caption absolute top-0 w-full h-full flex flex-col justify-between p-6 text-white">
          <div className="card-number w-7.5 h-7.5 bg-white inline-flex justify-center items-center text-black rounded-2xl">1</div>
          <div className="card-discription">
            <p className="w-[90%]">{user.tag}</p>
            <button className="flex align-center items-center gap-5 mt-5 cursor-pointer ">
              <div className="button-text  bg-amber-300 py-1.5 px-5 rounded-2xl ">View More</div>
              <div className="button-icon bg-amber-300 py-1.5 w-9 h-9 rounded-2xl"><i className="ri-arrow-right-line"></i></div>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default Card;
