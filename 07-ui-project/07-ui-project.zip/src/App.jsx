import React from "react";
import Parent from "./components/Parent";

const user = [
  {
    img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7",
    intro: "",
    tag:"Satisfied",
    btntext: "View More",
    btncolor: "bg-amber-300",
  },
   {
    img: "https://plus.unsplash.com/premium_photo-1661641353075-f0eaf2d82aae?",
    intro: "",
    tag:"UnderServed",
    btntext: "View More",
    btncolor: "bg-amber-300",
  },
  {
    img: "https://plus.unsplash.com/premium_photo-1658506656752-4f1b1c1d5916?",
    intro: "",
    tag:"Underbanked",
    btntext: "View More",
    btncolor: "bg-amber-300",
  }

]


function App() {
  return (
    <>
      <Parent  user={user} />
    </>
  );
}

export default App;
